package com.cts.selenium;

import com.cts.selenium.controller.Gmail;
import com.cts.selenium.controller.Images;
import com.cts.selenium.model.GoogleInterface;

public class MainTest {

	public static void main(String[] args) {

		GoogleInterface in = new Gmail();
		in.driverClick();
		GoogleInterface in2 = new Images();
		in2.driverClick();
	}
}

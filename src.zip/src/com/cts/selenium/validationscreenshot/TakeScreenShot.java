package com.cts.selenium.validationscreenshot;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TakeScreenShot {
	WebDriver driver;

	@Test
	public void testGmailClickScreenShot() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("https://google.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		try {
			driver.findElement(By.xpath("hfhdfdjhhdfjdfkjj")).click();
		} catch (Exception e) {
			System.out.println("Element not found ");
			takeScreenshot();
			// tearDown(); 
		}

	}

	public void takeScreenshot() throws Exception {

		File sc = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		FileUtils.copyFile(sc, new File("D://testresults/failed-test.png"));
	}

}


// //*[text()="Give Disc"]
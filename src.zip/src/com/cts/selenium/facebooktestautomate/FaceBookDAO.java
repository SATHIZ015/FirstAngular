package com.cts.selenium.facebooktestautomate;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FaceBookDAO {
	public static WebDriver source() {

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		return driver;
	}

	/*
	 * public static List elementProvide() { WebDriver driver = source();
	 * List<WebElement> me =
	 * driver.findElements(By.xpath("//*[@class='inputtext _58mg _5dba _2ph-']")
	 * ); return me; }
	 */
}

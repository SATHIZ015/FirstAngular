package com.cts.selenium.facebooktestautomate;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FaceBookTestController extends FaceBookDAO {

	public void click() {

		WebDriver driver = FaceBookDAO.source();

		if (driver.getTitle().equalsIgnoreCase("Sign up for Facebook | Facebook")) {

			WebElement firstname = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[1]"));

			firstname.click();
			firstname.sendKeys("sathish");

			WebElement lastname = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[2]"));

			lastname.click();
			lastname.sendKeys("kumar");

			WebElement mobilenumber = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[3]"));

			mobilenumber.click();
			mobilenumber.sendKeys("89749384842");

			WebElement newPassword = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[6]"));

			newPassword.click();
			newPassword.sendKeys("uoiw634365");

			Select dd = new Select(driver.findElement(By.name("birthday_day")));
			dd.selectByVisibleText("14");

			Select mm = new Select(driver.findElement(By.name("birthday_month")));
			mm.selectByVisibleText("Apr");

			Select yy = new Select(driver.findElement(By.name("birthday_year")));
			yy.selectByVisibleText("1996");

		}

		else if (driver.getTitle().equalsIgnoreCase("Access to this site is blocked")) {
			driver.switchTo().frame("ws_blockoption");
			WebElement usequotatime;
			usequotatime = driver.findElement(By.xpath("//*[@id='quota-text']/input"));
			usequotatime.click();

			WebElement firstname = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[1]"));

			firstname.click();
			firstname.sendKeys("sathish");

			WebElement lastname = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[2]"));

			lastname.click();
			lastname.sendKeys("kumar");

			WebElement mobilenumber = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[3]"));

			mobilenumber.click();
			mobilenumber.sendKeys("89749384842");

			WebElement newPassword = driver.findElement(By.xpath("(//*[@class='inputtext _58mg _5dba _2ph-'])[6]"));

			newPassword.click();
			newPassword.sendKeys("uoiw634365");

			Select dd = new Select(driver.findElement(By.name("birthday_day")));
			dd.selectByVisibleText("14");

			Select mm = new Select(driver.findElement(By.name("birthday_month")));
			mm.selectByVisibleText("Apr");

			Select yy = new Select(driver.findElement(By.name("birthday_year")));
			yy.selectByVisibleText("1996");
		}

	}
}

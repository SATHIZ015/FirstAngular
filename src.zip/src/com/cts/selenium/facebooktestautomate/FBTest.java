package com.cts.selenium.facebooktestautomate;

public class FBTest {
	public static void main(String[] args) {
		FaceBookTestController con = new FaceBookTestController();
		con.click();

	}

}

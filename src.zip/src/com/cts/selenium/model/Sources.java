package com.cts.selenium.model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sources {

	public static WebDriver driverGet() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		// driver.get("https://google.com");

		driver.get(
				"https://accounts.google.com/signup/v2/webcreateaccount?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Dwm&ltmpl=default&gmb=exp&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp");

		// driver.manage().window().maximize();

		return driver;
	}
	
	/*public void static readExcel(){
		XSSF 
		
	}*/
	
	

}

package com.cts.selenium.model;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public interface GoogleInterface {
	/*default WebDriver click() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get("https://google.com");
		return driver;
	}
*/
	void driverClick();

}

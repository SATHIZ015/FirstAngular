package com.cts.selenium;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/*public class TestClass {
	public static void main(String[] args) {
		WebDriver driver;

		System.setProperty("webdriver.chrome.driver",
				"D:\\Automation\\AutomationTesting1\\Driver\\chromedriver 2.33.exe");

		driver = new ChromeDriver();

		driver.get("https://www.google.com/");
		//
		// WebElement searchBar =
		// driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input"));
		//
		// searchBar.click();
		// driver.findElement(By.name("q")).sendKeys("hello");

		WebElement searchButton = driver.findElement(By.name("q"));
		searchButton.click();
		//driver.findElement(By.className("(//input[@class='gNO89b'])[2]")).click();

	}

}//input[@class='gNO89b'])[2]
//// *[@id="tsf"]/div[2]/div/div[1]/div/div[1]/input



//  //*[title()="gmail"]*/

public class TestClass {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();

		List<WebElement> wb = driver.findElements(By.xpath("//*[class='gb_d']"));
		wb.get(0).click();
		wb.get(1).click();
	}

}
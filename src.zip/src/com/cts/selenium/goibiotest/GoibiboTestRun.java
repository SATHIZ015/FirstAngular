package com.cts.selenium.goibiotest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoibiboTestRun {

	WebDriver driver;

	@BeforeTest
	public void launchSite() {

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.get(
				"https://www.goibibo.com/bus/?gclid=EAIaIQobChMIjuLU2-Xv4gIVwRErCh3MDQieEAAYASAAEgKr3vD_BwE&ef_id=EAIaIQobChMIjuLU2-Xv4gIVwRErCh3MDQieEAAYASAAEgKr3vD_BwE:G:s#home/?utm_source=google&utm_medium=cpc&utm_campaign=Bus-Brand-EM&utm_content=Goibibo_Bus&campaign=Bus-Brand-EM");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testTextField() throws Exception {
		driver.findElement(By.xpath("//*[@class='form-control inputTxtLarge fromTxt']")).sendKeys("Chennai, Tamil Nadu",
				Keys.ARROW_DOWN, Keys.ENTER);
		driver.findElement(By.xpath("//*[@class='form-control inputTxtLarge toTxt']")).sendKeys("Coimbatore",
				Keys.ARROW_DOWN, Keys.ENTER);

		
		driver.findElement(By.xpath("//*[@id='jrdp_start-calen_5_19_2019']/div/span")).click();

		driver.findElement(By.xpath("//*[@class='width100 button orange xlarge']")).click();

	}

}

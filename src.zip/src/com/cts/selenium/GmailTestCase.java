package com.cts.selenium;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.sourceforge.htmlunit.corejs.javascript.tools.debugger.Main;

public class GmailTestCase {
	public static void main(String[] args) {
		WebDriver driver = null;

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("https://google.com");
		WebDriverWait wait = new WebDriverWait(driver, 200);

		WebElement gmail = wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='gbw']/div/div/div[1]/div[1]/a")));
		gmail.click();

		WebElement signin = driver.findElement(By.xpath("(//a[@title='Create an account'])[1]"));
		signin.click();

		ArrayList<String> tabs2 = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		WebElement fname = driver.findElement(By.name("firstName"));
		fname.click();
		fname.clear();
		fname.sendKeys("CSK");

		WebElement lname = driver.findElement(By.name("lastName"));
		lname.click();
		lname.clear();
		lname.sendKeys("chennai");

		WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("Username")));
		username.click();
		username.clear();
		username.sendKeys("cskchennai8");

		WebElement password = driver.findElement(By.name("Passwd"));
		password.click();
		password.clear();
		password.sendKeys("csk1234");

		WebElement confirm = driver.findElement(By.name("ConfirmPasswd"));
		confirm.click();
		confirm.clear();
		confirm.sendKeys("csk1234");

	}

}

package com.cts.selenium.xcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadTest {
	// public static void main(String[] args) throws Exception {

	public static void main(String... str) throws Exception {

		File input = new File("D:\\Automation\\AutomationTesting1\\Files\\Read.xlsx");

		FileInputStream fs = new FileInputStream(input);

		XSSFWorkbook work = new XSSFWorkbook();

		XSSFSheet sheet = work.getSheet("Sheet2");

		// sheet.getRow(1).getCell(1).setCellValue("ish");
		// sheet.getRow(2).getCell(1).setCellValue("ish");
		// sheet.getRow(3).getCell(1).setCellValue("ish");
		// sheet.getRow(4).getCell(1).setCellValue("ish");

		System.out.println(sheet.getRow(0).getCell(0).getStringCellValue());
		
		

		FileOutputStream fout = new FileOutputStream(input);
		work.write(fout);

	}

}

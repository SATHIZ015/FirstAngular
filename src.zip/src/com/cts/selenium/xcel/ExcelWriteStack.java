package com.cts.selenium.xcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

class ExcelWriteStack {
	public static void main(String[] args) {
		File f = new File("D:\\Automation\\AutomationTesting1\\Files\\Excel Write.xlsx");

		try {
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook workBook = new XSSFWorkbook(fin);

			XSSFSheet sheet = workBook.createSheet("WritingInYou");

			// XSSFRow row = sheet.getRow(0);

			for (int i = 0; i < 5; i++) {
				sheet.createRow(i);
				sheet.getRow(i).createCell(0).setCellValue("IAM>>>>");
			}

			FileOutputStream fout = new FileOutputStream(f);

			workBook.write(fout);

			fin.close();
			fout.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
}

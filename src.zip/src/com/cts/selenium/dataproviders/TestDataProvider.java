package com.cts.selenium.dataproviders;

import org.testng.annotations.Test;

public class TestDataProvider {
	@Test(dataProvider = "data-provider", dataProviderClass = DataProviderClass.class)
	public void testMethod(String data) {
		System.out.println("Data is :" + data);
	}

}

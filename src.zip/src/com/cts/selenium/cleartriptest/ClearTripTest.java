package com.cts.selenium.cleartriptest;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ClearTripTest {
	public void testClearTrip() {
		WebDriver driver = SourceClear.driverGet();

		WebElement roundButton = driver.findElement(By.xpath("(//*[@class='tripType'])[2]"));
		roundButton.click();

		WebElement from = driver.findElement(By.xpath(
				"(//*[@class='keyValue span span24 required arabicChars ui-autocomplete-input placeholder'])[1]"));

		from.click();
		from.sendKeys("Chennai, IN - Chennai Airport (MAA)");
		from.sendKeys(Keys.TAB);

		WebElement to = driver.findElement(By.xpath(
				"(//*[@class='keyValue span span24 required arabicChars ui-autocomplete-input placeholder'])[2]"));

		to.click();
		to.sendKeys("Chennai, IN - Chennai Airport (MAA)");
		//to.sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[5]/td[5]/a")).click();
		driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[1]/td[6]/a")).click();

		Select adult = new Select(driver.findElement(By.xpath("//*[@id='Adults']")));
		adult.selectByVisibleText("7");

		Select child = new Select(driver.findElement(By.xpath("//*[@id='Childrens']")));
		child.selectByVisibleText("2");

		Select infant = new Select(driver.findElement(By.xpath("//*[@id='Infants']")));
		infant.selectByVisibleText("1");

	}

}

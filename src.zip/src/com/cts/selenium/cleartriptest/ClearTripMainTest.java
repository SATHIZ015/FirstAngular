package com.cts.selenium.cleartriptest;

public class ClearTripMainTest {
	public static void main(String[] args) {
		ClearTripTest test = new ClearTripTest();
		test.testClearTrip();
	}

}

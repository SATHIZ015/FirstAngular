package com.cts.selenium.cleartriptest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SourceClear {
	public static WebDriver driverGet() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.get(
				"https://www.cleartrip.com/?dxid=EAIaIQobChMIpon3j9HF4gIVxhmPCh1d2gejEAAYASAAEgLnHfD_BwE&gclid=EAIaIQobChMIpon3j9HF4gIVxhmPCh1d2gejEAAYASAAEgLnHfD_BwE");

		return driver;

	}

}

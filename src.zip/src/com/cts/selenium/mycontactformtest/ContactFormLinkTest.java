package com.cts.selenium.mycontactformtest;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

public class ContactFormLinkTest {

	public void testLinkList() {
		List generalContactForm = new ArrayList<>();
		generalContactForm.add("//*[@id='left_col_top']/ul[1]/li[1]/a");
		generalContactForm.add("//*[@id='left_col_top']/ul[1]/li[2]/a");

		List webFeedbackForm = new ArrayList();
		webFeedbackForm.add("//*[@id='left_col_top']/ul[2]/li[1]/a");
		webFeedbackForm.add("//*[@id='left_col_top']/ul[2]/li[2]/a");
		webFeedbackForm.add("//*[@id='left_col_top']/ul[2]/li[3]/a");
		webFeedbackForm.add("//*[@id='left_col_top']/ul[2]/li[4]/a");

		List businessForm = new ArrayList<>();
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[1]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[2]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[3]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[4]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[5]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[6]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[7]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[8]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[9]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[10]/a");
		businessForm.add("//*[@id='left_col_top']/ul[3]/li[11]/a");

		List registrationAndReservation = new ArrayList();
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[1]/a");
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[2]/a");
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[3]/a");

		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[4]/a");

		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[5]/a");

		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[6]/a");
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li71]/a");
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[8]/a");
		registrationAndReservation.add("//*[@id='left_col_top']/ul[4]/li[9]/a");

		List  surveys=new ArrayList();
		surveys.add("//*[@id='left_col_top']/ul[5]/li[1]/a");
		
		
		List<WebElement> weblink=new ArrayList<>();
		
		
		
		
		//for(int i=0;i<)
	}

}

package com.cts.selenium.keyboardmouse;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SeleniumBase {

	Robot r;

	public void performShift() throws AWTException {
		r = new Robot();
		r.keyPress(KeyEvent.VK_SHIFT);
	}

	public void controlPress() throws AWTException {
		r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
	}

	public void enterPress() throws AWTException {
		r = new Robot();

		r.keyPress(KeyEvent.VK_ENTER);
	}

	public void tabPress() throws AWTException {
		r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
	}

	public XSSFSheet excelRead() throws Exception {
		File f = new File("D:\\Automation\\AutomationTesting1\\Files\\Read.xlsx");

		FileInputStream fin = new FileInputStream(f);
		XSSFWorkbook book = new XSSFWorkbook(fin);

		XSSFSheet sheet = book.getSheetAt(0);

		// int rowcount = sheet.getLastRowNum();

		return sheet;
	}

	public void selectAll() {
		try {
			r = new Robot();

			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_A);

		} catch (AWTException e) {

			e.printStackTrace();
		}

	}

	public void releaseKey() throws AWTException {
		r = new Robot();
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyRelease(KeyEvent.VK_A);
	}

}

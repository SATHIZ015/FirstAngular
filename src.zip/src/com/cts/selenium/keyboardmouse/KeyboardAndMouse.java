package com.cts.selenium.keyboardmouse;

public class KeyboardAndMouse {
	public static void main(String[] args) throws Exception {
		GmailTestExcelRead test = new GmailTestExcelRead();
		test.gmailTest();

	}

}

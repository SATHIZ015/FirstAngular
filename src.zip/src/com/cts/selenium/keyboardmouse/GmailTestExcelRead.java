package com.cts.selenium.keyboardmouse;

import java.awt.AWTException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cts.selenium.model.Sources;

public class GmailTestExcelRead {
	public void gmailTest() throws Exception {
		WebDriver driver = Sources.driverGet();

		SeleniumBase base = new SeleniumBase();

		XSSFSheet sheet = base.excelRead();

		WebElement firstName = driver.findElement(By.xpath("(//*[@class='whsOnd zHQkBf'])[1]"));
		firstName.click();
		firstName.sendKeys(sheet.getRow(0).getCell(0).getStringCellValue());
		base.tabPress();

		WebElement lastName = driver.findElement(By.xpath("(//*[@class='whsOnd zHQkBf'])[2]"));
		// WebElement lastName = null;
		lastName.sendKeys(sheet.getRow(1).getCell(0).getStringCellValue());
		base.tabPress();

		WebElement userName = driver.findElement(By.xpath("(//*[@class='whsOnd zHQkBf'])[3]"));
		userName.sendKeys(sheet.getRow(2).getCell(0).getStringCellValue());
		base.tabPress();

		WebElement password = driver.findElement(By.xpath("(//*[@class='whsOnd zHQkBf'])[4]"));

		password.sendKeys(sheet.getRow(3).getCell(0).getStringCellValue());
		base.tabPress();

		WebElement confirmPassword = driver.findElement(By.xpath("(//*[@class='whsOnd zHQkBf'])[5]"));

		confirmPassword.sendKeys(sheet.getRow(4).getCell(0).getStringCellValue());
		base.tabPress();

		base.enterPress();

		// for next button
		base.tabPress();

		base.selectAll();
	
		//Thread.sleep(1000);
		Thread.sleep(100);

		base.releaseKey();

		Thread.sleep(10000);
		// base.releaseKey();

		
		base.enterPress();
 
	}

}

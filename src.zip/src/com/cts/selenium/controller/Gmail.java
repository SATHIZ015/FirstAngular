package com.cts.selenium.controller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cts.selenium.model.GoogleInterface;
import com.cts.selenium.model.Sources;
import com.cts.selenium.pageobject.PageObject;

public class Gmail extends Sources implements GoogleInterface {
	@Override
	public void driverClick() {

		WebDriver driver = Sources.driverGet();

		// WebDriver driver = GoogleInterface.super.click();

		WebElement gmail = driver.findElement(PageObject.gmail);
		gmail.click();

	}

}

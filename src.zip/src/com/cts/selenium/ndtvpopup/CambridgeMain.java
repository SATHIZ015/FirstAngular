package com.cts.selenium.ndtvpopup;

import java.awt.AWTException;

public class CambridgeMain {
	public static void main(String[] args) {

		CambridgeAssessmentTest test = new CambridgeAssessmentTest();
		try {
			test.cambridgeTest();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

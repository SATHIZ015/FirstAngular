package com.cts.selenium.ndtvpopup;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CambridgeAssessmentTestBase {
	public static WebDriver sources() {

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		// Robot r=new Robot

		// driver.switchTo().frame((WebElement)
		// driver.findElements(By.linkText("'https://www.googletagmanager.com/ns.html?id=GTM-WGLKFN']")));
		// driver.findElement(By.xpath("(//*[@class='anchor--linked-content--external'])[7]")).click();

		// driver.findElement(By.xpath("//*[@id='navigation_list-1559631620813-9']/div[2]/div[2]/div/ul/li[5]/a/span")).click();
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("https://www.cambridgeassessment.org.uk/");

		// StaleElementReferenceException

		return driver;

	}

}

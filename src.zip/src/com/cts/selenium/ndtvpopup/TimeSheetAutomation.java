package com.cts.selenium.ndtvpopup;

import java.awt.AWTException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TimeSheetAutomation {

	public void timeSheetAutomation() {

	}

	public static void main(String[] args) {

		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");
		 * 
		 * WebDriver driver = new ChromeDriver();
		 * 
		 * driver.get(
		 * "https://compass.esa.cognizant.com/psc/ESA89PRD/EMPLOYEE/ERP/c/ADMINISTER_EXPENSE_FUNCTIONS.CTS_TS_LAND_COMP.GBL?Action=A&local_date=2019-06-04"
		 * );
		 * 
		 * driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 * driver.manage().window().maximize();
		 * 
		 * // driver.findElement(By.xpath(
		 * "//*[@id='uxhgnn2zdp']/div/div[1]/div/a[1]/p[2]/span")).click();
		 * 
		 * List<WebElement> spansClick =
		 * driver.findElements(By.xpath("//*[@class='ps-link']"));
		 * 
		 * for (int i = 0; i < spansClick.size(); i++) {
		 * spansClick.get(9).click();
		 * 
		 * }
		 */

		TimeSheetBase time = new TimeSheetBase();

		try {
			time.timeSheetTest();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

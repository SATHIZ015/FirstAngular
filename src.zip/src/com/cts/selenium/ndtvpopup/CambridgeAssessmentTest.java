package com.cts.selenium.ndtvpopup;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CambridgeAssessmentTest {
	public void cambridgeTest() throws AWTException {
		WebDriver driver = CambridgeAssessmentTestBase.sources();

		List<WebElement> list = driver.findElements(By.xpath("//*[@class='anchor--linked-content--external']"));

		for (int i = 0; i < list.size(); i++) {
			if (i == 6) {
				// driver.findElements(By.xpath("(//*[@class='anchor--linked-content--external'])")).get(i).click();

				// driver.manage().timeouts().implicitlyWait(10,
				// TimeUnit.SECONDS);
				// List<WebElement> list2 =
				// driver.findElements(By.xpath("//*[@class='link--external']"));
				// list2.get(7).click();

				Robot r = new Robot();
				driver.findElement(By.xpath("(//*[@class='anchor--linked-content--external'])[7]")).click();

				driver.findElements(By.xpath("//*[@class='yui3-g']")).get(3).click();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				driver.findElements(By.xpath("//*[@class='navigation--space']")).get(9).click();

				// list.get(6).click();#navigation_list-1559801564156-9 >
				// div.yui3-g > div:nth-child(2) > div > ul > li:nth-child(5) >
				// a > span

			}
		}

	}

}

package com.cts.selenium.ndtvpopup;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TimeSheetBase {
	// public static Robot r;

	public static void keysForEnter() throws AWTException {

		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);

	}

	public static void keysForTab() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);

	}

	public void timeSheetTest() throws AWTException {
		WebDriver driver = timeSheetBase();

		driver.findElement(By.xpath("//*[@id='txtPlatformBarSearch']")).sendKeys("Timesheet");

		// driver.findElement(By.xpath("//*[@id='btnsearch'])"));

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		keysForTab();
		keysForEnter();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		List<WebElement> clicks = driver.findElements(By.xpath("//*[@class='inActive']"));// get(0).click();
		for (int i = 0; i < clicks.size(); i++) {
			clicks.get(0).click();
		}

		// driver.switchTo().activeElement();//
		// findElements(By.xpath("//*[@class='ps-link']")).get(9).click();

	}

	public static WebDriver timeSheetBase() {

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://onecognizant.cognizant.com/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		return driver;
	}
}

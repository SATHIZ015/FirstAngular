package com.cts.selenium.testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AnnotationSequence {
	WebDriver driver;

	@BeforeTest
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.irctc.co.in/nget/train-search");

		System.out.println("This is before the test annotations.........");
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("this is before class..........");

	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("This is before method .......");

	}

	@Test
	public void testAnnotation() {
		System.out.println("This is test method.......");
	}

	@AfterClass
	public void testAfterClass() {
		System.out.println("After the class annotation......");

	}

	@AfterMethod
	public void testAfterMethod() {
		System.out.println("After the test method.......");
	}

	@AfterTest
	public void afterTest() {
		driver.quit();
		System.out.println("This is after the test method........");
	}

}

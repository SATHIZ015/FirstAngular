package com.cts.selenium.testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGFirst {
	WebDriver driver;

	@Test
	public void print() {

		System.out.println("hello ..............");
		//Assert.assertEquals(actual, expected);

	}

	@BeforeTest
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get("https://www.cambridgeassessment.org.uk/");

	}

	@AfterTest
	public void afterTest() {
		driver.quit();

	}

}

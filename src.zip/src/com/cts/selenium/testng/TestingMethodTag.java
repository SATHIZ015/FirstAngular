package com.cts.selenium.testng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestingMethodTag {

	WebDriver driver;

	@BeforeTest
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://www.google.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);

	}

	@Test(priority = 0)
	public void testTextField() {

		driver.findElement(By.xpath("//*[@class='gLFyf gsfi']")).click();

	}

	@Test(priority = 1)
	public void testGmailLink() {
		driver.findElement(By.xpath("//*[@id='gbw']/div/div/div[1]/div[1]/a")).click();
	}

	@AfterTest
	public void testOfPageClose() {
		driver.quit();
	}

}

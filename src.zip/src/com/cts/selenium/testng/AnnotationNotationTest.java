package com.cts.selenium.testng;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AnnotationNotationTest {

	WebDriver driver;

	@BeforeTest
	public void sourceLaunchBrowser() {

		System.setProperty("webdriver.chrome.driver", "D:\\Automation\\AutomationTesting1\\drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.irctc.co.in/nget/train-search");

	}

	@BeforeMethod
	public void WaitToFind() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("successfully find......");
	}

	@Test(priority = 0)
	public void testFrom() {
		WebElement from = driver.findElement(By.xpath("//*[@id='origin']/span/input"));
		System.out.println("Successfully find");
		from.click();
		from.sendKeys("KOLKATA - KOAA");

	}

	@AfterMethod
	public void resultAfterTest() {
		try {
			Robot r = new Robot();

			r.keyPress(KeyEvent.VK_TAB);

		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	@Test(priority = 1)
	public void testTo() {
		WebElement to = driver.findElement(By.xpath("//*[@id='destination']/span/input"));
		to.click();
		to.sendKeys("CHENNAI CHETPAT - MSC");

	}

	@Test(priority = 2)
	public void testFindTrains() {
		driver.findElements(By.xpath("//*[@class='search_btn']")).get(1).click();
	}

	@AfterTest
	public void tearPage() {
		driver.quit();
	}

}

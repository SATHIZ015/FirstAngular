package com.cts.selenium.pageobject;

import org.openqa.selenium.By;

public class PageObject {
	public static final By gmail = By.xpath("(//*[@class='gb_d'])[1]");
	public static final By images = By.xpath("(//*[@class='gb_d'])[2]");
	
	
	
	//  //*[text()='Gmail']c

}

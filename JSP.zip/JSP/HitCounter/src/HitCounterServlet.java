
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HitCounterServlet
 */
public class HitCounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int count;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HitCounterServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		count++;
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		response.getWriter().append("Served at: ").append(request.getContextPath());

		out.print("<body bgcolor='#341E4C'>");
		out.print("<font font-face='comic sans ms' color='Yellow'>");
		out.print("<marquee> The application is being visited" + count + " times </marquee>");
		out.print("</font>");
		out.print("</body>");
	}

}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
	public static void main(String[] args) {

		Connection con = null;
		Statement stmt = null;
		String url = "jdbc:mysql://localhost:3306?user=root&password=root";

		String qry = "select * from emsdatabase.account";

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url);

			stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(qry);

			System.out.format("%-15s %-15s", "AC_Number", "Cust_ID");
			System.out.println();
			while (rs.next()) {

				System.out.format("%-15s %-15s", rs.getString(1), rs.getString(2));
				System.out.println();
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}

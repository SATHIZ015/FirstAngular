package com.cts.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HitCountServlet
 */
public class PersonalisedHitCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PersonalisedHitCountServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int counter = 0;
		Cookie c = null;
		Cookie[] cookieSet = request.getCookies();
		if (cookieSet == null) {
			c = new Cookie("myCookie", String.valueOf(++counter));
			response.addCookie(c);
		} else if (cookieSet[0].getName().equals("myCookie")) {
			c = cookieSet[0];
			counter = Integer.parseInt(c.getValue());
			counter++;
			out.print("<h1>U R visiting the web site for the " + counter + " times<br>");
			if (counter == 5)
				out.print("<h2>A surprise gift awaits U!!!</h2>");
			c.setValue(String.valueOf(counter));
			response.addCookie(c);

		}

	}
}

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) {
		Connection con = DBConnector.getConnection();
		String queryString = "select * from contact";
		Statement stmt = null;
		ResultSet result = null;
		try {
			stmt = con.createStatement();
			result = stmt.executeQuery(queryString);
			System.out.format("%-15s %-15s %-30s %-15s\n", "Firstname", "Lastname", "E-Mail", "Phone Number");
			while (result.next()) {
				System.out.format("%-15s %-15s %-30s %-15s\n", result.getString(2), result.getString(3),
						result.getString(4), result.getString(5));
			}
		} catch (SQLException sql) {
			sql.printStackTrace();
		}

	}

}

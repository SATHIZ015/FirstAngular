
public class Main {
	public static void main(String[] args) {
		if (args.length == 2) {
			int n = Integer.parseInt(args[0]);
			int s = Integer.parseInt(args[1]);
			System.out.println("The sum of " + args[0] + " and " + args[1] + " is " +(n+s));
		} else
			System.out.println("Invalid Input");
	}

}

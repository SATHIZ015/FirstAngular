import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ContactDAO {

	public List<Contact> getContactList() {
		// Creating an object of the 'ResourceBundle' class
		// for reading the properties from the '.properties' file
		ResourceBundle rb = ResourceBundle.getBundle("mysql");
		// Reading the properties
		String url = rb.getString("db.url");
		String username = rb.getString("db.username");
		String password = rb.getString("db.password");
		Connection con = null;
		Statement stmt = null;
		String queryString = "select * from contact";
		ResultSet result = null;
		List<Contact> contactList = new ArrayList<Contact>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
			stmt = con.createStatement();
			result = stmt.executeQuery(queryString);
			while (result.next()) {
				Contact c = new Contact(result.getString(2), result.getString(3), result.getString(4),
						result.getString(5));
				c.setId(result.getInt(1));
				// Adding the 'Contact' object to 'contactList'
				contactList.add(c);
			}
			// Returning the list

		} catch (Exception e) {
			e.printStackTrace();
		}
		return contactList;

	}

	public void addContact(Contact c) {
		ResourceBundle rb = ResourceBundle.getBundle("mysql");
		// Reading the properties
		String url = rb.getString("db.url");
		String username = rb.getString("db.username");
		String password = rb.getString("db.password");
		Connection con = null;
		PreparedStatement pstmt = null;
		String insertString = "insert into contact values(?,?,?,?,?)";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
			pstmt = con.prepareStatement(insertString);
			// Setting values for the input parameters
			pstmt.setInt(1, c.getId());
			pstmt.setString(2, c.getFirstName());
			pstmt.setString(3, c.getLastName());
			pstmt.setString(4, c.getEmail());
			pstmt.setString(5, c.getPhoneNumber());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Before the insert");
		ContactBO cbo = new ContactBO();
		cbo.printContacts();
		System.out.println("Enter Contact Table Inputs");
		System.out.println("Enter The FirstName :");
		String firstName = sc.next();
		System.out.println("Enter The LastName :");
		String lastName = sc.next();
		System.out.println("Enter The Email :");
		String email = sc.next();
		System.out.println("Enter The PhoneNumber :");
		String phoneNumber = sc.next();
		cbo.registerContact(firstName, lastName, email, phoneNumber);
		System.out.println("After the insert");
		cbo.printContacts();
	}

}

import java.util.List;

public class ContactBO {

	public void printContacts() {
		ContactDAO cdao = new ContactDAO();
		List<Contact> contactList = cdao.getContactList();
		System.out.format("%-15s %-15s %-30s %-15s\n", "FirstName", "LastName", "Email", "PhoneNumber");
		for (Contact c : contactList) {
			System.out.format("%-15s %-15s %-30s %-15s\n", c.getFirstName(), c.getLastName(), c.getEmail(),
					c.getPhoneNumber());
		}
	}

}

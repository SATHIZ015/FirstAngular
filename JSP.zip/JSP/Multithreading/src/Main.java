import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double sum;
		System.out.println("Enter the Degree for Sin : ");
		SineClass sin = new SineClass(sc.nextDouble());
		System.out.println("Enter the Degree for Cos : ");
		CosClass cos = new CosClass(sc.nextDouble());
		System.out.println("Enter the Degree for Tan : ");
		TanClass tan = new TanClass(sc.nextDouble());
		sin.start();
		cos.start();
		tan.start();
		try {
			sin.join();
			cos.join();
			tan.join();
			sum = sin.result + cos.result + tan.result;
			System.out.println("Sum of sin, cos, tan = " + String.format("%.2f", sum));
		} catch (Exception e) {
			e.printStackTrace();
		}
		sc.close();
	}
}

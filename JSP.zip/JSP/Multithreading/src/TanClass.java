
public class TanClass extends Thread {
	double deg, result, c;

	public TanClass(double degree) {
		deg = degree;
	}

	public void run() {
		c = Math.toRadians(deg);
		result = Math.tan(c);

	}
}

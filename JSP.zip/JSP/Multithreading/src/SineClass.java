
public class SineClass extends Thread {
	double deg, result, c;

	public SineClass(double degree) {
		deg = degree;
	}

	public void run() {
		c = Math.toRadians(deg);
		result = Math.sin(c);
	}

}

package com.cts.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Retrieving the 'customerId' from the request parameter
		String customerId = request.getParameter("customerId");
		Connection con = null;
		Statement stmt = null;
		String queryString = "select * from customer";
		ResultSet result = null;
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = null;

		try {
			// Loading the jdbc driver for mysql
			Class.forName("com.mysql.jdbc.Driver");
			// Establishing the connection with the database
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bms_db", "root", "root");
			// Creating the Statement object
			stmt = con.createStatement();
			// Executing the query
			result = stmt.executeQuery(queryString);
			// Checking for the 'customer_id' in the
			// ResultSet
			while (result.next()) {
				if (customerId.equals(result.getString(1))) {
					out.print("<h2>Login is successdul..</h2>");
					// Setting 'customerId' as the request attribute
					request.setAttribute("custId", customerId);
					// Creating the RequestDispatcher object
					rd = request.getRequestDispatcher("CustomerProfileServlet");
					// Dispatching the request
					rd.include(request, response);
				}
			}

		} catch (ClassNotFoundException cnf) {
			cnf.printStackTrace();
		} catch (SQLException sql) {
			sql.printStackTrace();
		}
	}

}

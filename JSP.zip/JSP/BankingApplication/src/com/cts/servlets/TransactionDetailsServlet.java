package com.cts.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TransactionDetailsServlet
 */
public class TransactionDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TransactionDetailsServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String customerId = (String) request.getAttribute("custId");
		PrintWriter out = response.getWriter();
		Connection con = null;
		String queryString = "select * from trandetails where " + " acnumber in " + " ("
				+ " select acnumber from account where " + " custid in" + " ("
				+ " select custid from customer where custid=? " + " )" + " )  ";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// Establishing the connection with the database
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bms_db", "root", "root");
			pstmt = con.prepareStatement(queryString);
			pstmt.setString(1, customerId);
			result = pstmt.executeQuery();
			// Creating a html table to print the customer information
			out.print("<table border='2'>");
			out.print("<tr>");
			out.print("<th>Transaction NO</th>");
			out.print("<th>A/C NO</th>");
			out.print("<th>Transaction Date</th>");
			out.print("<th>Transaction Mode</th>");
			out.print("<th>Transaction Type</th>");
			out.print("<th>Amount</th>");
			out.print("</tr>");
			while (result.next()) {
				// Printing the table row
				out.print("<tr>");
				// out.print("<td><b>Tansaction No :</td>");
				out.print("<td>" + result.getString(1) + "</td>");
				// out.print("<td><b>A/C No :</td>");
				out.print("<td>" + result.getString(2) + "</td>");
				// out.print("<td><b>Transaction Date :</td>");

				out.print("<td>" + result.getDate(3) + "</td>");
				// out.print("<td><b>Medium of Transaction :</td>");
				out.print("<td>" + result.getString(4) + "</td>");
				// out.print("<td><b>Trnsaction Type :</td>");
				out.print("<td>" + result.getString(5) + "</td>");
				// out.print("<td><b>Amount :</td>");
				out.print("<td>" + result.getInt(6) + "</td>");
				out.print("</tr>");

			}
			out.print("</table>");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

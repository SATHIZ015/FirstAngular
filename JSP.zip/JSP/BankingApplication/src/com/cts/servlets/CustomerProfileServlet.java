package com.cts.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerProfileServlet
 */
public class CustomerProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerProfileServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Retrieving the customerId whose profile information
		// is to be printed
		String customerId = (String) request.getAttribute("custId");
		PrintWriter out = response.getWriter();
		Connection con = null;
		String queryString = "select * from customer where custid=?";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		RequestDispatcher rd = null;
		try {
			// Loading the jdbc driver for mysql
			Class.forName("com.mysql.jdbc.Driver");
			// Establishing the connection with the database
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bms_db", "root", "root");
			pstmt = con.prepareStatement(queryString);
			pstmt.setString(1, customerId);
			result = pstmt.executeQuery();
			// Creating a html table to print the customer information
			out.print("<table border='2'>");
			while (result.next()) {
				// Printing the table row
				out.print("<tr>");
				out.print("<td><b>Customer ID :</td>");
				out.print("<td>" + result.getString(1) + "</td>");
				out.print("</tr>");
				out.print("<tr>");
				out.print("<td><b>First Name :</td>");
				out.print("<td>" + result.getString(2) + "</td>");
				out.print("</tr>");
				out.print("<tr>");
				out.print("<td><b>Middle Name :</td>");

				out.print("<td>" + result.getString(3) + "</td>");
				out.print("</tr>");
				out.print("<tr>");
				out.print("<td><b>Last Name :</td>");
				out.print("<td>" + result.getString(4) + "</td>");
				out.print("</tr>");
				out.print("<td><b>City :</td>");
				out.print("<td>" + result.getString(5) + "</td>");
				out.print("</tr>");
				out.print("<tr>");
				out.print("<td><b>Mobile :</td>");
				out.print("<td>" + result.getString(6) + "</td>");
				out.print("</tr>");
				out.print("<tr>");
				out.print("<td><b>Occupation :</td>");
				out.print("<td>" + result.getString(7) + "</td>");
				out.print("</tr>");
			}
			out.print("</table>");
			rd = request.getRequestDispatcher("TransactionDetailsServlet");
			rd.include(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

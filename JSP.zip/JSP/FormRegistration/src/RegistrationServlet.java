
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		String fullname = request.getParameter("Name");
		String username = request.getParameter("UserName");
		String password = request.getParameter("Password");
		String email = request.getParameter("Email");
		String mobileno = request.getParameter("MobileNo");

		PrintWriter out = response.getWriter();
		/*
		 * out.print("<html><title>Registration Form</title>" +
		 * "<body background bgcolor=' #800080'><h1>USER REGISTRATION</h1>" +
		 * "<p>FullName:" + fullname + "</p>" + "<p>USerNAME:" + username +
		 * "</p>" + "<p>Email: " + email + "</p>" + "<p>PassWord:" + password +
		 * "</p>" + "<p>MobileNo: " + mobileno + "</p>" + "</body></html>");
		 */

		out.println("<body bgcolor='#800080' >");
		// out.print("<body bgcolor='#341E4C'>");
		out.print("<font font-face='comic sans ms' color='Yellow'>");
		out.print("<p>" + fullname + "<p/>");
		out.print("<p>" + username + "<p/>");
		out.print("<p>" + password + "<p/>");
		out.print("<p>" + email + "<p/>");
		out.print("<p>" + mobileno + "<p/>");

		// out.print("<marquee> The application is being visited" + count + "
		// times </marquee>");
		out.print("</font>");
		out.print("</body>");
		doGet(request, response);
	}

}

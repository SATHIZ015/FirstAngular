import java.util.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ConvertOrderServlet
 */
public class ConfirmOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	List<Product>productList;
    public ConfirmOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		Product product=null;
		productList=null;
		if(session.getAttribute("cart")==null)
		{
			productList=new ArrayList<Product>();
		}
		else
		{
			productList=(List<Product>)session.getAttribute("cart");
			if(request.getParameter("LottoSubmit")!=null)
			{
				product=new Product();
				product.setName("Lotto");
				product.setPrice(3000);
				product.setUnits(Integer.parseInt(request.getParameter("txtLotto")));
				productList.add(product);
			}
			else if(request.getParameter("NikeSubmit")!=null)
			{
				product=new Product();
				product.setName("Nike");
				product.setPrice(4500);
				product.setUnits(Integer.parseInt(request.getParameter("txtNike")));
				productList.add(product);
			}
			
			else if(request.getParameter("BaccabuciSubmit")!=null)
			{
				product=new Product();
				product.setName("Baccabuci");
				product.setPrice(2500);
				product.setUnits(Integer.parseInt(request.getParameter("txtBaccabuci")));
				productList.add(product);
			}
			else if(request.getParameter("AdidasSubmit")!=null)
			{
				product=new Product();
				product.setName("Adidas");
				product.setPrice(2500);
				product.setUnits(Integer.parseInt(request.getParameter("txtAdidas")));
				productList.add(product);
			}
			
		}
		
		session.setAttribute("cart", productList);
		out.println("<a href='printbill'>Print Bill</a>");
		
	}

}

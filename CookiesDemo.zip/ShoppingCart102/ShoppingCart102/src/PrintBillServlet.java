
import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PrintBillServlet
 */
public class PrintBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrintBillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		List<Product>productList=(List<Product>)session.getAttribute("cart");
		out.println("<h1>Bill</h1><br>");
		out.println("<table>");
		out.println("<tr>");
		out.println("<th>Item</th>");
		out.println("<th>Name</th>");
		out.println("<th>Price</th>");
		out.println("<th>Qty</th>");
		out.println("<th>Value</th>");
		out.println("</tr>");
		int counter=0;
		for(Product p:productList)
		{
			counter++;
			out.println("<tr>");
			out.println("<td>"+counter+"</td>");
			out.println("<td>"+p.getName()+"</td>");
			out.println("<td>"+p.getPrice()+"</td>");
			out.println("<td>"+p.getUnits()+"</td>");
			out.println("<td>"+p.getPrice()*p.getUnits()+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		
	}

}

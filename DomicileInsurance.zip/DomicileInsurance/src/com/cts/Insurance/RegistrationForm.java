package com.cts.Insurance;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationForm extends InsuranceClass {

	// WebDriver driver;

	// Robot class
	public static void tab() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
	}

	public static void enter() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
	}

	public void takeScreenshot() throws Exception {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\Users\\776493\\Desktop\\project\\registerFAIL.png"));
	}

	// Registration Form for Reset Button

	// Registration Form For Valid data
	@Test(priority = 0)
	public void regFormValidData() throws Exception {
		driver.get("http://ctsc00849530701:9000/DomicileInsurance");
		driver.get("http://ctsc00849530701:9000/DomicileInsurance/RegisterUser.jsp");
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(1);
		XSSFRow row = sheet.getRow(1);
		String userid = row.getCell(0).toString();
		String pass = row.getCell(1).toString();
		String cpass = row.getCell(2).toString();
		String fname = row.getCell(3).toString();
		String lname = row.getCell(4).toString();
		String ssn = row.getCell(6).toString();
		String mail = row.getCell(7).toString();
		String contactno = row.getCell(8).toString();
		String Address1 = row.getCell(9).toString();
		String Address2 = row.getCell(10).toString();
		String zipcode = row.getCell(11).toString();
		String month = row.getCell(12).toString();
		String year = row.getCell(13).getRawValue().toString();
		driver.findElement(By.xpath(DataObjectClass.puserid)).sendKeys(userid);
		driver.findElement(By.xpath(DataObjectClass.ppass)).sendKeys(pass);
		driver.findElement(By.xpath(DataObjectClass.pcpass)).sendKeys(cpass);
		driver.findElement(By.xpath(DataObjectClass.pfname)).sendKeys(fname);
		driver.findElement(By.xpath(DataObjectClass.plname)).sendKeys(lname);
		WebElement web = driver.findElement(By.xpath(DataObjectClass.pcal));
		web.click();
		Select sel1 = new Select(driver.findElement((By.xpath(DataObjectClass.pyear))));
		sel1.selectByVisibleText(year);
		Select sel = new Select(driver.findElement((By.xpath(DataObjectClass.pmonth))));
		sel.selectByVisibleText(month);
		driver.findElement((By.xpath(DataObjectClass.pday))).click();
		driver.findElement(By.xpath(DataObjectClass.pssn)).sendKeys(ssn);
		enter();
		tab();
		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		alert.accept();
		enter();
		WebElement web1 = driver.findElement(By.xpath(DataObjectClass.pmail));
		web1.sendKeys(mail);

		WebElement wbb = driver.findElement(By.xpath(DataObjectClass.pcontactno));
		wbb.sendKeys(contactno);
		wbb.click();
		// tab();
		takeScreenshot();

		// tearDown();
		WebElement wb1 = driver.findElement(By.xpath(DataObjectClass.paddress1));
		wb1.click();
		wb1.sendKeys(Address1);
		driver.findElement(By.xpath(DataObjectClass.paddress2)).sendKeys(Address2);
		/*
		 * try { Alert alert1=driver.switchTo().alert(); alert1.accept(); }
		 * 
		 * catch(Exception e) { takeScreenshot(); }
		 */
		WebElement web11 = driver.findElement(By.xpath(DataObjectClass.pzipcode));
		web11.click();
		Select sel11 = new Select(driver.findElement((By.xpath(DataObjectClass.pzipcode))));
		sel11.selectByVisibleText(zipcode);
		WebElement sub = driver.findElement(By.xpath(DataObjectClass.pregister));
		sub.click();
		wb.close();
	}

	// @BeforeTest
	// public void LaunchBrowser() {
	// System.setProperty("webdriver.chrome.driver",
	// "D:\\java_prog\\DomicileInsurance\\chrome\\chromedriver.exe");
	//
	// driver = new ChromeDriver();
	// // driver.manage().window().maximize();
	// driver.get("http://ctsc00849530701:9000/DomicileInsurance");
	// }

	// @Test(priority=2)
	// public void tearDown() throws Exception
	// {
	// //takeScreenshot();
	// driver.quit();
	// }

}

package com.cts.Insurance;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class InsuranceClass {
	 WebDriver driver;

	// To launch browser
	@BeforeSuite
	public void launchBrowser() {
		 WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "D:\\java_prog\\DomicileInsurance\\chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://ctsc00849530701:9000/DomicileInsurance");
	}

	// Header navigation
	@Test(priority = 0)
	public void headerNavigation() throws InterruptedException {
		// Home tab
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/index.jsp");
		Thread.sleep(1000);
		// Register tab
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/RegisterUser.jsp");
		Thread.sleep(1000);
		// Login tab
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/welcome.jsp");
		Thread.sleep(1000);
		// About us tab
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/aboutUs.jsp");
		Thread.sleep(1000);
		// Contact us tab
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/contactUs.jsp");
		Thread.sleep(1000);
	}

	@Test(priority = 1)
	// Footer navigation
	public void footerNavigation() throws InterruptedException {
		// Home link
		WebElement home = driver.findElement(By.linkText("Home Page"));
		home.click();
		Thread.sleep(1000);
		// Register link
		WebElement register = driver.findElement(By.linkText("Register"));
		register.click();
		Thread.sleep(1000);
		// Login link
		WebElement login = driver.findElement(By.linkText("Login"));
		login.click();
		Thread.sleep(1000);
		// About us link
		WebElement about = driver.findElement(By.linkText("About Us"));
		about.click();
		Thread.sleep(1000);
		// Contact us link
		WebElement contact = driver.findElement(By.linkText("Contact Us"));
		contact.click();
		Thread.sleep(1000);

	}

	// Verification of content before login
	// Home page content verification
	@Test(priority = 2)
	public void homePageContentVerification() throws IOException, InterruptedException {

		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/");
		Thread.sleep(1000);
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = wbook.getSheetAt(0);
		String actual = sheet.getRow(1).getCell(0).getStringCellValue();
		WebElement data = driver.findElement(By.xpath("//*[text()='Domicile is a leading Global Insurance company']"));
		String expected = data.getText();
		Assert.assertEquals(expected, actual);
		System.out.print("Home page content displayed as expected\n");
		wbook.close();

	}

	// About us page content verification
	@Test(priority = 3)
	public void aboutUsPageContentVerification() throws InterruptedException, IOException {
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/aboutUs.jsp");
		Thread.sleep(1000);
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook1 = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wbook1.getSheetAt(0);
		String actual = sheet1.getRow(2).getCell(0).getStringCellValue();
		WebElement data = driver
				.findElement(By.xpath("//*[text()='Short information about Domicile Insurance company']"));
		String expected = data.getText();
		Assert.assertEquals(expected, actual);
		// About us page description verification
		String actual1 = sheet1.getRow(3).getCell(0).getStringCellValue();
		WebElement data1 = driver.findElement(By.xpath(
				"//*[text()='Domicile is a leading Global Insurance company. The company which was set up in 1991, to provide protection for property with affordable premium. Domicile has been expanding its presence across the country and is today present across 50 cities with 104 branches with an employee base of more than 700 plus professionals. Domicile is a name to reckon within the insurance market with the commitment it upholds for superior customer service delivery. Domicile believes that insurance plays an important role in protecting property. Through our comprehensive and innovative insurance solutions, we seek to redefine industry standards by offering unparalleled and empathetic service to every individual']"));
		String expected1 = data1.getText();
		Assert.assertEquals(expected1, actual1);
		System.out.print("About us page content displayed as expected\n");
		wbook1.close();

	}

	// Copyright content verification
	@Test(priority = 4)
	public void copyright() {
		driver.findElement(By.xpath("//h3[contains(.,'COPYRIGHT')]")).isDisplayed();

	}

	// Contact content verification
	@Test(priority = 5)
	public void contact() {
		driver.findElement(By.xpath("//h3[contains(.,'CONTACT')]")).isDisplayed();
	}

	// Login with invalid Credentials

	@Test(priority = 6)

	public void invalidLogin() {
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/welcome.jsp");
		driver.findElement(By.xpath("//*[@name='userName']")).click();
		driver.findElement(By.xpath("//*[@name='userName']")).sendKeys("karthi");
		driver.findElement(By.xpath("//*[@name='password']")).click();
		driver.findElement(By.xpath("//*[@name='password']")).sendKeys("Pass12345");
		driver.findElement(By.xpath("(//*[@class='submit'])[2]")).click();
	}

	@Test(priority = 7, dataProvider = "login", dataProviderClass = DomicileDataProviderClass.class)
	public void loginFrom(String login, String pass) {
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/welcome.jsp");

		driver.findElement(By.cssSelector(DataObjectClass.userName)).sendKeys(login);
		driver.findElement(By.cssSelector(DataObjectClass.password)).sendKeys(pass);

		driver.findElement(By.cssSelector(DataObjectClass.login)).click();

	}

	// Home page content verification after login
	@Test(priority = 8)
	public void content() throws IOException {
		FileInputStream fis = new FileInputStream("D:\\projectTable.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wbook.getSheetAt(0);
		// First row
		// Policy Key
		String pKey = sheet1.getRow(1).getCell(0).getStringCellValue();
		WebElement w1 = driver.findElement(By.xpath(DataObjectClass.policyKey));
		String str1 = w1.getText();
		Assert.assertEquals(str1, pKey);
		// Policy Effective date
		String pDate = sheet1.getRow(1).getCell(1).toString();
		String pMonth = sheet1.getRow(1).getCell(2).toString();
		String pYear = sheet1.getRow(1).getCell(3).getRawValue().toString();
		String con1 = pDate.concat(pMonth);
		String con2 = con1.concat(pYear);
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.policyEffectiveDate));
		String str2 = w2.getText();
		Assert.assertEquals(con2, str2);
		// Policy End date
		String pEndDate = sheet1.getRow(1).getCell(4).toString();
		String pEndMonth = sheet1.getRow(1).getCell(5).toString();
		String pEndYear = sheet1.getRow(1).getCell(6).getRawValue().toString();
		String conc1 = pEndDate.concat(pEndMonth);
		String conc2 = conc1.concat(pEndYear);
		WebElement w3 = driver.findElement(By.xpath(DataObjectClass.policyEndDate));
		String str3 = w3.getText();
		Assert.assertEquals(conc2, str3);
		// Policy Term
		Integer pTerm = (int) sheet1.getRow(1).getCell(7).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.policyTerm)).getText());
		Assert.assertEquals(w4, pTerm);
		// Policy Status
		String pStatus = sheet1.getRow(1).getCell(8).getStringCellValue();
		WebElement w5 = driver.findElement(By.xpath(DataObjectClass.policyStatus));
		String str5 = w5.getText();
		Assert.assertEquals(str5, pStatus);
		// Second row
		// Policy key
		String pKey1 = sheet1.getRow(2).getCell(0).getStringCellValue();
		WebElement w6 = driver.findElement(By.xpath(DataObjectClass.policyKey1));
		String str6 = w6.getText();
		Assert.assertEquals(str6, pKey1);
		// Policy effective date
		String pDate1 = sheet1.getRow(2).getCell(1).toString();
		String pMonth1 = sheet1.getRow(2).getCell(2).toString();
		String pYear1 = sheet1.getRow(2).getCell(3).getRawValue().toString();
		String con11 = pDate1.concat(pMonth1);
		String con22 = con11.concat(pYear1);
		WebElement w7 = driver.findElement(By.xpath(DataObjectClass.policyEffectiveDate1));
		String str7 = w7.getText();
		Assert.assertEquals(con22, str7);
		// Policy End date
		String pEndDate1 = sheet1.getRow(2).getCell(4).toString();
		String pEndMonth1 = sheet1.getRow(2).getCell(5).toString();
		String pEndYear1 = sheet1.getRow(2).getCell(6).getRawValue().toString();
		String conc11 = pEndDate1.concat(pEndMonth1);
		String conc22 = conc11.concat(pEndYear1);
		WebElement w8 = driver.findElement(By.xpath(DataObjectClass.policyEndDate1));
		String str8 = w8.getText();
		Assert.assertEquals(conc22, str8);
		// Policy Term
		Integer pTerm1 = (int) sheet1.getRow(2).getCell(7).getNumericCellValue();
		Integer w9 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.policyTerm1)).getText());
		Assert.assertEquals(w9, pTerm1);
		// Policy Status
		String pStatus1 = sheet1.getRow(2).getCell(8).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.policyStatus1));
		String str10 = w10.getText();
		Assert.assertEquals(str10, pStatus1);
		System.out.print("Login home page content displyed properly\n");
		wbook.close();
	}

	@Test(priority = 9, dataProvider = "getQuote", dataProviderClass = DomicileDataProviderClass.class)
	public void insideLoginTab(String residenceType, String residenceUse, String builtUpArea, String marketValue,
			String homeBuilt, String dwellingStyle, String roofMaterial, String garage, String addressLine,
			String addressLine2, String zip) {
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/property.jsp");
		String homePage = driver.getWindowHandle();
		Select rt = new Select(driver.findElement(By.xpath(DataObjectClass.residenceType)));
		rt.getOptions().contains(residenceType);
		rt.selectByVisibleText(residenceType);
		Select rs = new Select(driver.findElement(By.xpath(DataObjectClass.residenceUse)));
		rs.selectByVisibleText(residenceUse);
		WebElement bu = driver.findElement(By.xpath(DataObjectClass.builtuparea));
		bu.clear();
		bu.click();
		bu.sendKeys(builtUpArea);
		WebElement mv = driver.findElement(By.xpath(DataObjectClass.marketValue));
		mv.clear();
		mv.click();
		mv.sendKeys(marketValue);
		// Home Built year entering
		WebElement hb = driver.findElement(By.xpath(DataObjectClass.originallyBuilt));
		hb.clear();
		hb.click();
		// Selecting the year
		Select yearCal = new Select(driver.findElement(By.xpath(DataObjectClass.yearCalender)));
		yearCal.selectByVisibleText(homeBuilt);
		// Clicking the Button
		driver.findElement(By.xpath(DataObjectClass.doneCalender)).click();
		Select ds = new Select(driver.findElement(By.xpath(DataObjectClass.dwellingStyle)));
		ds.selectByVisibleText(dwellingStyle);
		Select rm = new Select(driver.findElement(By.xpath(DataObjectClass.roofMaterial)));
		rm.selectByVisibleText(roofMaterial);
		Select ga = new Select(driver.findElement((By.xpath(DataObjectClass.typeOfGarag))));
		ga.selectByVisibleText(garage);
		WebElement spn = driver.findElement(By.cssSelector(DataObjectClass.swimmingPoolNo));
		// spn.clear();
		spn.click();
		WebElement ad1 = driver.findElement(By.xpath(DataObjectClass.addressLine1));
		ad1.clear();
		ad1.click();
		ad1.sendKeys(addressLine);
		WebElement ad2 = driver.findElement(By.xpath(DataObjectClass.addressLine2));
		ad2.clear();
		ad2.click();
		ad2.sendKeys(addressLine2);
		Select zp = new Select(driver.findElement(By.xpath(DataObjectClass.zip)));
		zp.selectByVisibleText(zip);
		WebElement quoteSubmit = driver.findElement(By.cssSelector(DataObjectClass.generateQuote));
		if (quoteSubmit.isDisplayed()) {
			quoteSubmit.click();
		}
		// String formSubmitPage = driver.getWindowHandle();
		WebElement clickDetails = driver.findElement(By.xpath(DataObjectClass.clickLink));
		if (clickDetails.isDisplayed()) {
			clickDetails.click();
		}
		// driver.switchTo().window(formSubmitPage);
		// for coming again to the getQuotePage form page
		// WebDriverWait wait = new WebDriverWait(driver, 100);
		driver.switchTo().window(homePage);
		// driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/property.jsp");
		// driver.navigate().to();
		// driver.navigate().refresh();
		// driver.get(driver.getCurrentUrl());
	}

	/*
	 * 
	 * 
	 * @Test public void webTable() { //To locate table. WebElement mytable =
	 * driver.findElement(By.xpath("//*[@class='hovertable']/tbody")); //To
	 * locate rows of table. List < WebElement > rows_table =
	 * mytable.findElements(By.tagName("tr")); //To calculate no of rows In
	 * table. int rows_count = rows_table.size(); //Loop will execute till the
	 * last row of table. for (int row = 0; row < rows_count; row++) { //To
	 * locate columns(cells) of that specific row. List < WebElement >
	 * Columns_row = rows_table.get(row).findElements(By.tagName("td")); //To
	 * calculate no of columns (cells). In that specific row. int columns_count
	 * = Columns_row.size(); //System.out.println("Number of cells In Row " +
	 * row + " are " + columns_count); //Loop will execute till the last cell of
	 * that specific row. for (int column = 0; column < columns_count; column++)
	 * {
	 * 
	 * // To retrieve text from that specific cell.
	 * 
	 * String celtext = Columns_row.get(column).getText(); int cellValue =
	 * Integer.parseInt(celtext);
	 * 
	 * if(cellValue == 211) {
	 * driver.findElement(By.xpath("(//*[@class='submit'])[column]")).click(); }
	 * 
	 * //Assert.assertEquals("211",
	 * driver.findElement(By.xpath("//*[@class='hovertable']/tbody/tr/td")).
	 * getText()); //System.out.println(celtext); //clicking
	 * "view quote and buy policy" button
	 * 
	 * 
	 * } //System.out.
	 * println("-------------------------------------------------- "); }
	 * 
	 * }
	 */

	@Test(priority = 10)
	public void quoteDetailsDataVerification() throws InterruptedException, IOException {
		/*
		 * WebElement mytable =
		 * driver.findElement(By.xpath("//*[@class='hovertable']/tbody")); //To
		 * locate rows of table. List < WebElement > rows_table =
		 * mytable.findElements(By.tagName("tr")); //To calculate no of rows In
		 * table. int rows_count = rows_table.size(); //Loop will execute till
		 * the last row of table. for (int row = 0; row < rows_count; row++) {
		 * //To locate columns(cells) of that specific row. List < WebElement >
		 * Columns_row = rows_table.get(row).findElements(By.tagName("td"));
		 * //To calculate no of columns (cells). In that specific row. int
		 * columns_count = Columns_row.size(); //
		 * System.out.println("Number of cells In Row " + row + " are " +
		 * columns_count); //Loop will execute till the last cell of that
		 * specific row. for (int column = 0; column < columns_count; column++)
		 * { // To retrieve text from that specific cell. String celtext =
		 * Columns_row.get(column).getText();
		 * //System.out.println("Cell Value of row number " + row +
		 * " and column number " + column + " Is " + celtext); } // System.out.
		 * println("-------------------------------------------------- ");
		 */

		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/retrieveQuote.jsp");
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = wbook.getSheetAt(7);

		// Quote id1
		Integer ex1 = (int) sheet.getRow(1).getCell(0).getNumericCellValue();
		Integer w1 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.quoteid1)).getText());
		Assert.assertEquals(w1, ex1);

		// Residence Type1
		String ex2 = sheet.getRow(1).getCell(1).getStringCellValue();
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.residencetype1));
		String s2 = w2.getText();
		Assert.assertEquals(s2, ex2);

		// Residence Use1
		String ex3 = sheet.getRow(1).getCell(2).getStringCellValue();
		WebElement w3 = driver.findElement(By.xpath(DataObjectClass.residenceuse1));
		String s3 = w3.getText();
		Assert.assertEquals(s3, ex3);

		// Market Value1
		Integer ex4 = (int) sheet.getRow(1).getCell(3).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.marketvalue1)).getText());
		Assert.assertEquals(w4, ex4);

		// Year Built1
		Integer ex5 = (int) sheet.getRow(1).getCell(4).getNumericCellValue();
		Integer w5 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.yearbuilt1)).getText());
		Assert.assertEquals(w5, ex5);

		// Square Meter1
		Integer ex6 = (int) sheet.getRow(1).getCell(5).getNumericCellValue();
		Integer w6 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.squaremeter1)).getText());
		Assert.assertEquals(w6, ex6);

		// Quote id2
		Integer ex8 = (int) sheet.getRow(2).getCell(0).getNumericCellValue();
		Integer w8 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.quoteid2)).getText());
		Assert.assertEquals(w8, ex8);

		// Residence Type2
		String ex9 = sheet.getRow(2).getCell(1).getStringCellValue();
		WebElement w9 = driver.findElement(By.xpath(DataObjectClass.residencetype2));
		String s9 = w9.getText();
		Assert.assertEquals(s9, ex9);

		// Residence Use2
		String ex10 = sheet.getRow(2).getCell(2).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.residenceuse2));
		String s10 = w10.getText();
		Assert.assertEquals(s10, ex10);

		// Market Value2
		Integer ex11 = (int) sheet.getRow(2).getCell(3).getNumericCellValue();
		Integer w11 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.marketvalue2)).getText());
		Assert.assertEquals(w11, ex11);

		// Year Built2
		Integer ex12 = (int) sheet.getRow(2).getCell(4).getNumericCellValue();
		Integer w12 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.yearbuilt2)).getText());
		Assert.assertEquals(w12, ex12);

		// Square Meter2
		Integer ex13 = (int) sheet.getRow(2).getCell(5).getNumericCellValue();
		Integer w13 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.squaremeter2)).getText());
		Assert.assertEquals(w13, ex13);
		wbook.close();
	}

	@Test(priority = 11)
	public void quoteSummaryDataVerification() throws IOException, InterruptedException {

		// clicking "View and buy quote" button
		driver.findElement(By.xpath("(//*[@class='submit'])[1]")).click();

		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = wbook.getSheetAt(6);

		// Residence Type
		String ex1 = sheet.getRow(1).getCell(0).getStringCellValue();
		WebElement w1 = driver.findElement(By.xpath(DataObjectClass.residencetype));
		String s1 = w1.getText();
		Assert.assertEquals(s1, ex1);

		// Residence Use
		String ex2 = sheet.getRow(1).getCell(1).getStringCellValue();
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.residenceuse));
		String s2 = w2.getText();
		Assert.assertEquals(s2, ex2);

		// Market Value
		Integer ex3 = (int) sheet.getRow(1).getCell(2).getNumericCellValue();
		Integer w3 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.marketvalue)).getText());
		Assert.assertEquals(w3, ex3);

		// Year Built
		Integer ex4 = (int) sheet.getRow(1).getCell(3).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.yearbuilt)).getText());
		Assert.assertEquals(w4, ex4);

		// Square Footage
		Integer ex5 = (int) sheet.getRow(1).getCell(4).getNumericCellValue();
		Integer w5 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.squarefootage)).getText());
		Assert.assertEquals(w5, ex5);

		/*
		 * //Dwelling Style (float) Integer ex6=(int)
		 * sheet.getRow(1).getCell(5).getNumericCellValue(); Integer
		 * w6=Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.
		 * dwellingstyle)).getText()); Assert.assertEquals(w6,ex6);
		 * 
		 * //Roof Material String
		 * ex7=sheet.getRow(1).getCell(6).getStringCellValue(); WebElement
		 * w7=driver.findElement(By.xpath(DataObjectClass.roofmaterial)); String
		 * s7=w7.getText(); Assert.assertEquals(s7,ex7);
		 * 
		 * //Garage Type String
		 * ex8=sheet.getRow(1).getCell(7).getStringCellValue(); WebElement
		 * w8=driver.findElement(By.xpath(DataObjectClass.garagetype)); String
		 * s8=w8.getText(); Assert.assertEquals(s8,ex8);
		 * 
		 * //Has Swimming Pool String
		 * ex9=sheet.getRow(1).getCell(8).getStringCellValue(); WebElement
		 * w9=driver.findElement(By.xpath(DataObjectClass.hasswimmingpool));
		 * String s9=w9.getText(); Assert.assertEquals(s9,ex9);
		 */

		// Address Line1
		String ex10 = sheet.getRow(1).getCell(9).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.addressline1));
		String s10 = w10.getText();
		Assert.assertEquals(s10, ex10);

		// Address Line2
		String ex11 = sheet.getRow(1).getCell(10).getStringCellValue();
		WebElement w11 = driver.findElement(By.xpath(DataObjectClass.addressline2));
		String s11 = w11.getText();
		Assert.assertEquals(s11, ex11);

		// Zip
		Integer ex12 = (int) sheet.getRow(1).getCell(11).getNumericCellValue();
		Integer w12 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.zipm)).getText());
		Assert.assertEquals(w12, ex12);

		// City
		String ex13 = sheet.getRow(1).getCell(12).getStringCellValue();
		WebElement w13 = driver.findElement(By.xpath(DataObjectClass.city));
		String s13 = w13.getText();
		Assert.assertEquals(s13, ex13);
		wbook.close();

	}

	@Test(priority = 12)
	public void document() throws InterruptedException {
		// Clicking "Click here to know about fields" button
		Thread.sleep(2000);
		driver.findElement(By.xpath(DataObjectClass.clickheretoknowaboutfields)).click();

		// switching tab

		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		driver.switchTo().window(tabs2.get(0));

		// scroll down
		JavascriptExecutor down = (JavascriptExecutor) driver;
		down.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(1000);
		driver.findElement(By.xpath(DataObjectClass.buypolicybutton)).click();
	}

	@Test(priority = 13)
	public void buyPolicyForm() throws IOException, InterruptedException {

		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(10);

		XSSFRow row = sheet.getRow(1);

		String sel1 = row.getCell(0).toString();

		String sel2 = row.getCell(1).toString();
		String cardno = row.getCell(2).getRawValue().toString();
		String name = row.getCell(3).toString();
		String cvv = row.getCell(4).toString();
		String year1 = row.getCell(5).getRawValue().toString();
		String month1 = row.getCell(6).toString();
		String yearn = row.getCell(7).getRawValue().toString();
		String monthn = row.getCell(8).toString();
		Select sel11 = new Select(driver.findElement((By.xpath("(//*[@class='select'])[1]"))));
		sel11.selectByVisibleText(sel1);
		Select sel12 = new Select(driver.findElement((By.xpath("(//*[@class='select'])[2]"))));
		sel12.selectByVisibleText(sel2);
		driver.findElement(By.xpath("(//*[@class='text'])[1]")).sendKeys(cardno);
		driver.findElement(By.xpath("(//*[@class='text'])[2]")).sendKeys(name);
		driver.findElement(By.xpath("(//*[@class='text'])[3]")).sendKeys(cvv);
		WebElement web = driver.findElement(By.xpath("(//*[@id='datePicker1'])"));
		web.click();
		Select year = new Select(driver.findElement((By.xpath("(//*[@class='ui-datepicker-year'])"))));
		year.selectByVisibleText(year1);

		Select month = new Select(driver.findElement((By.xpath("(//*[@class='ui-datepicker-month'])"))));
		month.selectByVisibleText(month1);
		WebElement date = driver.findElement(By.xpath("//*[text()='Done']"));
		date.click();

		WebElement datenew = driver.findElement(By.xpath("(//*[@id='datePicker'])"));
		datenew.click();
		Select yearnew = new Select(driver.findElement((By.xpath("(//*[@class='ui-datepicker-year'])"))));
		yearnew.selectByVisibleText(yearn);
		Select monthnew = new Select(driver.findElement((By.xpath("(//*[@class='ui-datepicker-month'])"))));
		monthnew.selectByVisibleText(monthn);

		driver.findElement((By.xpath("(//*[@class='ui-state-default'])[10]"))).click();
		driver.findElement((By.xpath("(//*[@class='right'])[10]"))).click();
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		driver.switchTo().window(tabs2.get(0));
		driver.findElement((By.xpath("(//*[@class='submit'])"))).click();
		wb.close();

	}

	@Test(priority = 14)
	public void retrieveQuoteDataVerification() throws IOException, InterruptedException {
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/retrieveQuoteForView.jsp");

		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = wbook.getSheetAt(8);

		// QuoteId1
		Integer ex1 = (int) sheet.getRow(1).getCell(0).getNumericCellValue();
		Integer w1 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rquoteid1)).getText());
		Assert.assertEquals(w1, ex1);

		// Residence Type1
		String ex2 = sheet.getRow(1).getCell(1).getStringCellValue();
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.rresidencetype1));
		String s2 = w2.getText();
		Assert.assertEquals(s2, ex2);

		// Residence Use1
		String ex3 = sheet.getRow(1).getCell(2).getStringCellValue();
		WebElement w3 = driver.findElement(By.xpath(DataObjectClass.rresidenceuse1));
		String s3 = w3.getText();
		Assert.assertEquals(s3, ex3);

		// Market Value1
		Integer ex4 = (int) sheet.getRow(1).getCell(3).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rmarketvalue1)).getText());
		Assert.assertEquals(w4, ex4);

		// Year Build1
		Integer ex5 = (int) sheet.getRow(1).getCell(4).getNumericCellValue();
		Integer w5 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.ryearbuild1)).getText());
		Assert.assertEquals(w5, ex5);

		// Square Meter1
		Integer ex6 = (int) sheet.getRow(1).getCell(5).getNumericCellValue();
		Integer w6 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rsquaremeter1)).getText());
		Assert.assertEquals(w6, ex6);

		// QuoteId2
		Integer ex8 = (int) sheet.getRow(2).getCell(0).getNumericCellValue();
		Integer w8 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rquoteid2)).getText());
		Assert.assertEquals(w8, ex8);

		// Residence Type2
		String ex9 = sheet.getRow(2).getCell(1).getStringCellValue();
		WebElement w9 = driver.findElement(By.xpath(DataObjectClass.rresidencetype2));
		String s9 = w9.getText();
		Assert.assertEquals(s9, ex9);

		// Residence Use2
		String ex10 = sheet.getRow(2).getCell(2).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.rresidenceuse2));
		String s10 = w10.getText();
		Assert.assertEquals(s10, ex10);

		// Market Value2
		Integer ex11 = (int) sheet.getRow(2).getCell(3).getNumericCellValue();
		Integer w11 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rmarketvalue2)).getText());
		Assert.assertEquals(w11, ex11);

		// Year Build2
		Integer ex12 = (int) sheet.getRow(2).getCell(4).getNumericCellValue();
		Integer w12 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.ryearbuild2)).getText());
		Assert.assertEquals(w12, ex12);

		// Square Meter2
		Integer ex13 = (int) sheet.getRow(2).getCell(5).getNumericCellValue();
		Integer w13 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rsquaremeter2)).getText());
		Assert.assertEquals(w13, ex13);

		// clicking "View Quote" button
		driver.findElement(By.xpath(DataObjectClass.viewquotebutton)).click();
		Thread.sleep(2000);
		wbook.close();
	}

	@Test(priority = 15)
	public void retrieveQuoteSummaryDataVerification() throws IOException, InterruptedException {

		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = wbook.getSheetAt(9);

		// Residence Type
		String ex1 = sheet.getRow(1).getCell(0).getStringCellValue();
		WebElement w1 = driver.findElement(By.xpath(DataObjectClass.rresidencetype));
		String s1 = w1.getText();
		Assert.assertEquals(s1, ex1);

		// Residence Use
		String ex2 = sheet.getRow(1).getCell(1).getStringCellValue();
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.rresidenceuse));
		String s2 = w2.getText();
		Assert.assertEquals(s2, ex2);

		// Market Value
		Integer ex3 = (int) sheet.getRow(1).getCell(2).getNumericCellValue();
		Integer w3 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rmarketvalue)).getText());
		Assert.assertEquals(w3, ex3);

		// Year Built
		Integer ex4 = (int) sheet.getRow(1).getCell(3).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.ryearbuilt)).getText());
		Assert.assertEquals(w4, ex4);

		// Square Footage
		Integer ex5 = (int) sheet.getRow(1).getCell(4).getNumericCellValue();
		Integer w5 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rsquarefootage)).getText());
		Assert.assertEquals(w5, ex5);

		/*
		 * //Dwelling Style (float) Integer ex6=(int)
		 * sheet.getRow(1).getCell(5).getNumericCellValue(); Integer
		 * w6=Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.
		 * rdwellingstyle)).getText()); Assert.assertEquals(w6,ex6);
		 * 
		 * //Roof Material String
		 * ex7=sheet.getRow(1).getCell(6).getStringCellValue(); WebElement
		 * w7=driver.findElement(By.xpath(DataObjectClass.rroofmaterial));
		 * String s7=w7.getText(); Assert.assertEquals(s7,ex7);
		 * 
		 * //Garage Type String
		 * ex8=sheet.getRow(1).getCell(7).getStringCellValue(); WebElement
		 * w8=driver.findElement(By.xpath(DataObjectClass.rgaragetype)); String
		 * s8=w8.getText(); Assert.assertEquals(s8,ex8);
		 * 
		 * //Has Swimming Pool String
		 * ex9=sheet.getRow(1).getCell(8).getStringCellValue(); WebElement
		 * w9=driver.findElement(By.xpath(DataObjectClass.rhasswimmingpool));
		 * String s9=w9.getText(); Assert.assertEquals(s9,ex9);
		 */

		// Address Line1
		String ex10 = sheet.getRow(1).getCell(9).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.raddressline1));
		String s10 = w10.getText();
		Assert.assertEquals(s10, ex10);

		// Address Line2
		String ex11 = sheet.getRow(1).getCell(10).getStringCellValue();
		WebElement w11 = driver.findElement(By.xpath(DataObjectClass.raddressline2));
		String s11 = w11.getText();
		Assert.assertEquals(s11, ex11);

		// Zip
		Integer ex12 = (int) sheet.getRow(1).getCell(11).getNumericCellValue();
		Integer w12 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.rzip)).getText());
		Assert.assertEquals(w12, ex12);

		// City
		String ex13 = sheet.getRow(1).getCell(12).getStringCellValue();
		WebElement w13 = driver.findElement(By.xpath(DataObjectClass.rcity));
		String s13 = w13.getText();
		Assert.assertEquals(s13, ex13);

		// Clicking "Click here to know about fields" button
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@class='button']")).click();

		// switching tab

		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		driver.switchTo().window(tabs2.get(0));

		// scroll down
		JavascriptExecutor down = (JavascriptExecutor) driver;
		down.executeScript("window.scrollBy(0,1000)");

		// Clicking Back button
		Thread.sleep(3000);
		driver.findElement(By.xpath(DataObjectClass.backbutton)).click();
		wbook.close();
	}

	// Claim policy content
	@Test(priority = 16)
	public void claimPolicycontent() throws IOException {
		driver.findElement(By.xpath("//*[text()='CLAIM POLICY']")).click();
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = wbook.getSheetAt(2);

		// First row
		// Policy Key
		String pKey = sheet1.getRow(1).getCell(0).getStringCellValue();
		WebElement w1 = driver.findElement(By.xpath(DataObjectClass.policyKey));
		String str1 = w1.getText();
		Assert.assertEquals(str1, pKey);

		// Policy Effective date
		String pDate = sheet1.getRow(1).getCell(1).toString();
		String pMonth = sheet1.getRow(1).getCell(2).toString();
		String pYear = sheet1.getRow(1).getCell(3).getRawValue().toString();
		String con1 = pDate.concat(pMonth);
		String con2 = con1.concat(pYear);
		WebElement w2 = driver.findElement(By.xpath(DataObjectClass.policyEffectiveDate));
		String str2 = w2.getText();
		Assert.assertEquals(con2, str2);

		// Policy End date
		String pEndDate = sheet1.getRow(1).getCell(4).toString();
		String pEndMonth = sheet1.getRow(1).getCell(5).toString();
		String pEndYear = sheet1.getRow(1).getCell(6).getRawValue().toString();
		String conc1 = pEndDate.concat(pEndMonth);
		String conc2 = conc1.concat(pEndYear);
		WebElement w3 = driver.findElement(By.xpath(DataObjectClass.policyEndDate));
		String str3 = w3.getText();
		Assert.assertEquals(conc2, str3);

		// Policy Term
		Integer pTerm = (int) sheet1.getRow(1).getCell(7).getNumericCellValue();
		Integer w4 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.policyTerm)).getText());
		Assert.assertEquals(w4, pTerm);

		// Policy Status
		String pStatus = sheet1.getRow(1).getCell(8).getStringCellValue();
		WebElement w5 = driver.findElement(By.xpath(DataObjectClass.policyStatus));
		String str5 = w5.getText();
		Assert.assertEquals(str5, pStatus);

		// Claim policy submit
		// driver.findElement(By.xpath(DataObjectClass.claimpolicysubmit1)).click();

		// Second row
		// Policy key
		String pKey1 = sheet1.getRow(2).getCell(0).getStringCellValue();
		WebElement w6 = driver.findElement(By.xpath(DataObjectClass.policyKey1));
		String str6 = w6.getText();
		Assert.assertEquals(str6, pKey1);

		// Policy effective date
		String pDate1 = sheet1.getRow(2).getCell(1).toString();
		String pMonth1 = sheet1.getRow(2).getCell(2).toString();
		String pYear1 = sheet1.getRow(2).getCell(3).getRawValue().toString();
		String con11 = pDate1.concat(pMonth1);
		String con22 = con11.concat(pYear1);
		WebElement w7 = driver.findElement(By.xpath(DataObjectClass.policyEffectiveDate1));
		String str7 = w7.getText();
		Assert.assertEquals(con22, str7);

		// Policy End date
		String pEndDate1 = sheet1.getRow(2).getCell(4).toString();
		String pEndMonth1 = sheet1.getRow(2).getCell(5).toString();
		String pEndYear1 = sheet1.getRow(2).getCell(6).getRawValue().toString();
		String conc11 = pEndDate1.concat(pEndMonth1);
		String conc22 = conc11.concat(pEndYear1);
		WebElement w8 = driver.findElement(By.xpath(DataObjectClass.policyEndDate1));
		String str8 = w8.getText();
		Assert.assertEquals(conc22, str8);

		// Policy Term
		Integer pTerm1 = (int) sheet1.getRow(2).getCell(7).getNumericCellValue();
		Integer w9 = Integer.parseInt(driver.findElement(By.xpath(DataObjectClass.policyTerm1)).getText());
		Assert.assertEquals(w9, pTerm1);

		// Policy Status
		String pStatus1 = sheet1.getRow(2).getCell(8).getStringCellValue();
		WebElement w10 = driver.findElement(By.xpath(DataObjectClass.policyStatus1));
		String str10 = w10.getText();
		Assert.assertEquals(str10, pStatus1);

		// Claim policy submit
		driver.findElement(By.xpath(DataObjectClass.claimpolicysubmit2)).click();

		// System.out.print("Claim policy page content displyed properly\n");
		wbook.close();
	}

	// Claim policy
	@Test(priority = 17)
	public void claimPolicyForm() throws IOException, InterruptedException {

		// content
		WebElement checkBox1 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox1));
		checkBox1.click();
		WebElement checkBox2 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox2));
		checkBox2.click();
		WebElement checkBox3 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox3));
		checkBox3.click();
		WebElement checkBox4 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox4));
		checkBox4.click();
		WebElement checkBox5 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox5));
		checkBox5.click();
		WebElement checkBox6 = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyCheckBox6));
		checkBox6.click();

		WebElement message = driver.findElement(By.xpath(DataObjectClass.ClaimPolicyMessage));
		message.click();
		message.sendKeys(
				"In the event of a covered loss, this provides primary coverage for the medical expenses of a third-party who is injured while on the insured premises or is injured by an animal owned by or in the care of the insured person.");
		Thread.sleep(1500);

		// clicking "submit" button
		WebElement submitButton = driver.findElement(By.xpath(DataObjectClass.ClaimPolicySubmitButton));
		submitButton.click();
		// wb.close();

		// Logout
		driver.findElement(By.xpath("//*[text()='LOGOUT']")).click();
	}

	@Test(priority = 18)
	public void registerFormResetButton() throws IOException, AWTException, InterruptedException {
		driver.get("http://ctsc00849530701:9000/DomicileInsurance/RegisterUser.jsp");
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(1);
		XSSFRow row = sheet.getRow(1);
		String userid = row.getCell(0).toString();
		String pass = row.getCell(1).toString();
		String cpass = row.getCell(2).toString();
		String fname = row.getCell(3).toString();
		String lname = row.getCell(4).toString();
		String ssn = row.getCell(6).toString();
		String mail = row.getCell(7).toString();
		String month = row.getCell(12).toString();
		String year = row.getCell(13).getRawValue().toString();
		driver.findElement(By.xpath(DataObjectClass.puserid)).sendKeys(userid);
		driver.findElement(By.xpath(DataObjectClass.ppass)).sendKeys(pass);
		driver.findElement(By.xpath(DataObjectClass.pcpass)).sendKeys(cpass);
		driver.findElement(By.xpath(DataObjectClass.pfname)).sendKeys(fname);
		driver.findElement(By.xpath(DataObjectClass.plname)).sendKeys(lname);
		WebElement web = driver.findElement(By.xpath(DataObjectClass.pcal));
		web.click();
		Select sel1 = new Select(driver.findElement((By.xpath(DataObjectClass.pyear))));
		sel1.selectByVisibleText(year);
		Select sel = new Select(driver.findElement((By.xpath(DataObjectClass.pmonth))));
		sel.selectByVisibleText(month);
		driver.findElement((By.xpath(DataObjectClass.pday))).click();
		driver.findElement(By.xpath(DataObjectClass.pssn)).sendKeys(ssn);
		RegistrationForm.enter();
		RegistrationForm.tab();

		WebDriverWait wait = new WebDriverWait(driver, 40);
		wait.wait(50);

		Alert alert = driver.switchTo().alert();
		alert.accept();
		RegistrationForm.enter();
		WebElement web1 = driver.findElement(By.xpath(DataObjectClass.pmail));
		web1.sendKeys(mail);
		// scroll down
		JavascriptExecutor down = (JavascriptExecutor) driver;
		down.executeScript("window.scrollBy(0,1000)");
		// clicking "reset" button
		driver.findElement(By.xpath("(//*[@class='submit'])[2]")).click();
		wb.close();

	}

	// Tear Down

	// @AfterSuite
	// public void tearDown() {
	//
	// driver.quit();
	// }

}

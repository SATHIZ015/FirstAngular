package com.cts.Insurance;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DomicileDataProviderClass {
	@DataProvider(name = "getQuote")
	public static Object[][] readDataFromExcel() throws Exception {
		File f = new File("D:\\projectSample.xlsx");

		FileInputStream fin = new FileInputStream(f);

		XSSFWorkbook book = new XSSFWorkbook(fin);

		XSSFSheet sheet = book.getSheetAt(5);

		//XSSFRow rows = sheet.getRow(1);

	//	int rowCount = rows.getRowNum();

//		int colCount = rows.getPhysicalNumberOfCells();

		Object[][] quoteData = { { sheet.getRow(1).getCell(0).toString(), sheet.getRow(1).getCell(1).toString(),
				sheet.getRow(1).getCell(2).getRawValue().toString(),
				sheet.getRow(1).getCell(3).getRawValue().toString(),
				sheet.getRow(1).getCell(4).getRawValue().toString(), sheet.getRow(1).getCell(5).toString(),
				sheet.getRow(1).getCell(6).toString(), sheet.getRow(1).getCell(7).toString(),
				sheet.getRow(1).getCell(8).toString(), sheet.getRow(1).getCell(9).toString(),
				sheet.getRow(1).getCell(10).getRawValue().toString() } };
book.close();
		return quoteData;

	}

	@DataProvider(name = "login")
	public static Object[][] userLogin() throws Exception {
		File f = new File(DataObjectClass.xcelPath);

		FileInputStream fin = new FileInputStream(f);

		XSSFWorkbook book = new XSSFWorkbook(fin);

		XSSFSheet sheet = book.getSheet(DataObjectClass.sheetName);

		XSSFRow row = sheet.getRow(1);

		String as = row.getCell(0).toString();
		String ad = row.getCell(1).toString();

		Object[][] loginData = { { as, ad } };
book.close();
		return loginData;

	}

}

package com.cts.Insurance;

import org.testng.annotations.Test;

import com.cts.Insurance.DataObjectClass;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ContactUs extends InsuranceClass {

	public void takeScreenshot() throws Exception {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\Users\\776493\\Desktop\\project\\contactUsFAIL.png"));
	}

	// Contact us form
	@Test
	public void contactUsForm() throws Exception {
		driver.get("http://ctsc00849530701:9000/DomicileInsurance");
		driver.navigate().to("http://ctsc00849530701:9000/DomicileInsurance/contactUs.jsp");
		FileInputStream fis = new FileInputStream("D:\\projectSample.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(3);
		XSSFRow row = sheet.getRow(1);
		String fname = row.getCell(0).getStringCellValue();
		String email = row.getCell(1).getStringCellValue();
		String mobNumber = row.getCell(2).getRawValue().toString();
		String message = row.getCell(3).getStringCellValue();
		WebElement fname111 = driver.findElement(By.xpath(DataObjectClass.ContactUsUName));
		fname111.click();
		fname111.sendKeys(fname);
		WebElement email1 = driver.findElement(By.xpath(DataObjectClass.ContactUsEmail));
		email1.click();
		email1.sendKeys(email);
		WebElement mobNumber1 = driver.findElement(By.xpath(DataObjectClass.ContactUsMobNumber));
		mobNumber1.click();
		mobNumber1.sendKeys(mobNumber);
		takeScreenshot();
		WebElement message1 = driver.findElement(By.xpath(DataObjectClass.ContactUsMessage));

		message1.click();
		message1.sendKeys(message);

		WebElement submit = driver.findElement(By.xpath(DataObjectClass.ContactUsSubmit));
		submit.click();
		wb.close();
	}

	/*
	 * @BeforeTest public void LaunchBrowser() {
	 * System.setProperty("webdriver.chrome.driver",
	 * "D:\\java_prog\\DomicileInsurance\\chrome\\chromedriver.exe"); driver=new
	 * ChromeDriver(); driver.manage().window().maximize();
	 * driver.get("http://ctsc00849530701:9000/DomicileInsurance"); }
	 */

	// @Test(priority = 2)
	// public void tearDown() throws Exception {
	// // takeScreenshot();
	// driver.quit();
	// }

	@AfterSuite
	public void tearDown() {
		driver.quit();
	}

}

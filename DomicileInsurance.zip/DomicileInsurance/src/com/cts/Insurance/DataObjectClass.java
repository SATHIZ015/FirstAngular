package com.cts.Insurance;

public class DataObjectClass
{
	// Register form
    public static String puserid="(//*[@class='text'])[1]";
    public static String ppass="(//*[@class='text'])[2]";
    public static String pcpass="(//*[@class='text'])[3]";
    public static String pfname="(//*[@class='text'])[4]";
    public static String plname="(//*[@class='text'])[5]";
    public static String pcal="(//*[@id='datePicker'])";
    public static String pyear="(//*[@class='ui-datepicker-year'])";
    public static String pmonth="(//*[@class='ui-datepicker-month'])";
    public static String pday="(//*[@class='ui-state-default'])[6]";
    public static String pssn="(//*[@class='text'])[6]";
    public static String pmail="(//*[@class='text'])[7]";
    public static String pcontactno="(//*[@class='text'])[8]";
    public static String paddress1="(//*[@class='text'])[9]";
    public static String paddress2="(//*[@class='text'])[10]";
    public static String pzipcode="(//*[@class='select'])";
    public static String pregister="(//*[@class='submit'])[1]";
    

 // ---------------Contact Us-------------------------

    public static String ContactUsUName = "//*[@id='name']";
    public static String ContactUsEmail = "//*[@id='left']/table/tbody/tr[2]/td[2]/input";
    public static String ContactUsMobNumber = "//*[@id='mobileNumber']";
    public static String ContactUsMessage = "//*[@id='left']/table/tbody/tr[4]/td[2]/textarea";
    public static String ContactUsSubmit = "//*[@id='left']/table/tbody/tr[5]/td[2]/input";




	// Login Form details
	public static String userName = "input[type='text']";
	public static String password = "input[type='password']";
	public static String login = "input[type='submit']";

	// ----------------------------------------------------------------------------------------------------------------------------------

	// Get Quote form xpaths

	// select
	public static String residenceType = "//*[@name='residenceType']";

	// select
	public static String residenceUse = "// *[@name='residenceUse']";

	public static String builtuparea = "//*[@name='squareFootage']";
	public static String marketValue = "//*[@name='marketValue']";
	public static String originallyBuilt = "//*[@name='yearBuilt']";

	// Select
	public static String dwellingStyle = "//*[@name='dwellingStyle']";
	public static String roofMaterial = "//*[@name='roofMaterial']";
	public static String typeOfGarag = "//*[@name='garageType']";

	public static String swimmingPoolYes = "input[value=true]";
	public static String swimmingPoolNo = "input[value=false]";
	public static String addressLine1 = "//*[@name='addressLine1']";
	public static String addressLine2 = "//*[@name='addressLine2']";

	public static String yearCalender = "//*[@class='ui-datepicker-year']";
	public static String doneCalender = "//*[text()='Done']";

	// select
	public static String zip = "//*[@name='ZipCode']";

	// public static String city = "(//*[@class='right'])[13]";
	public static String generateQuote = "input[type=submit]";

	// After generate quote clicking the click to know more link
	public static String clickLink = "//*[text()='Click here to know about Fields']";

	// GetQuotePage link reload
	public static String getQuotelink = "//*[text()='GET QUOTE']";

	public static String linkText = "property.jsp";

	// --------------------------------------------------------------------------------------------------------------------------------------
	// Excel Sheet Path for GetQuote

	public static String xcelPath = "D:\\projectSample.xlsx";
	public static String sheetName = "Sheet5";
	public static int rowNumber = 2;



//Mani
	
	//----------------QuoteDetailsDataVerification--------------------------
		public static String quoteid1="(//*[@class='hovertable']/tbody/tr/td)[1]";
		public static String residencetype1="(//*[@class='hovertable']/tbody/tr/td)[2]";
		public static String residenceuse1="(//*[@class='hovertable']/tbody/tr/td)[3]";
		public static String marketvalue1="(//*[@class='hovertable']/tbody/tr/td)[4]";
		public static String yearbuilt1="(//*[@class='hovertable']/tbody/tr/td)[5]";
		public static String squaremeter1="(//*[@class='hovertable']/tbody/tr/td)[6]";
		public static String quoteid2="(//*[@class='hovertable']/tbody/tr/td)[8]";
		public static String residencetype2="(//*[@class='hovertable']/tbody/tr/td)[9]";
		public static String residenceuse2="(//*[@class='hovertable']/tbody/tr/td)[10]";
		public static String marketvalue2="(//*[@class='hovertable']/tbody/tr/td)[11]";
		public static String yearbuilt2="(//*[@class='hovertable']/tbody/tr/td)[12]";
		public static String squaremeter2="(//*[@class='hovertable']/tbody/tr/td)[13]";
		
		//-------------------QuoteSummaryDataVerification---------------------------
		public static String residencetype="(//*[@class='right'])[3]";
		public static String residenceuse="(//*[@class='right'])[4]";
		public static String marketvalue="(//*[@class='right'])[5]";
		public static String yearbuilt="(//*[@class='right'])[6]";
		public static String squarefootage="(//*[@class='right'])[7]";
		public static String dwellingstyle="(//*[@class='right'])[8]";
		public static String roofmaterial="//*[text()='Apartment']";
		public static String garagetype="(//*[@class='right'])[10]";
		public static String hasswimmingpool="(//*[@class='right'])[11]";
		public static String addressline1="(//*[@class='right'])[12]";
		public static String addressline2="(//*[@class='right'])[13]";
		public static String zipm="(//*[@class='right'])[14]";
		public static String city="(//*[@class='right'])[15]";
		
		//-------------------Document-----------------------------------------------
		public static String clickheretoknowaboutfields="//*[@class='button']";
		public static String buypolicybutton="//*[@class='submit']";
		
		//-------------------RetrieveQuoteDataVerification-----------------------------
		public static String rquoteid1="//*[text()='1']";
		public static String rresidencetype1="(//*[text()='Duplex'])[1]";
		public static String rresidenceuse1="(//*[text()='Secondary'])[1]";
		public static String rmarketvalue1="//*[text()='6000']";
		public static String ryearbuild1="(//*[text()='2008'])[1]";
		public static String rsquaremeter1="(//*[text()='500'])[1]";
		public static String rquoteid2="//*[text()='2']";
		public static String rresidencetype2="(//*[text()='Apartment'])[1]";
		public static String rresidenceuse2="(//*[text()='Primary'])[1]";
		public static String rmarketvalue2="( //*[text()='70000'])[1]";
		public static String ryearbuild2="(//*[text()='2017'])[1]";
		public static String rsquaremeter2="(//*[text()='1000'])[1]";
		
		public static String viewquotebutton="(//*[@class='submit'])[1]";
		
		//------------------RetrieveQuoteSummaryDataVerification-------------------------
		public static String rresidencetype="(//*[@class='right'])[3]";
		public static String rresidenceuse="(//*[@class='right'])[4]";
		public static String rmarketvalue="(//*[@class='right'])[5]";
		public static String ryearbuilt="(//*[@class='right'])[6]";
		public static String rsquarefootage="(//*[@class='right'])[7]";
		public static String rdwellingstyle="(//*[@class='right'])[8]";
		public static String rroofmaterial="//*[text()='Apartment']";
		public static String rgaragetype="(//*[@class='right'])[10]";
		public static String rhasswimmingpool="(//*[@class='right'])[11]";
		public static String raddressline1="(//*[@class='right'])[12]";
		public static String raddressline2="(//*[@class='right'])[13]";
		public static String rzip="(//*[@class='right'])[14]";
		public static String rcity="(//*[@class='right'])[15]";
		
		public static String backbutton="//*[@class='submit']";
		
		//-------------------BuyPolicyForm---------------------------------------------
	    public static String pcardtype="(//*[@class='select'])[1]";
	    public static String pcard="(//*[@class='select'])[2]";
	    public static String pcardno="(//*[@class='text'])[1]";
	    public static String pname="(//*[@class='text'])[2]";
	    public static String pcvv="(//*[@class='text'])[3]";
	    public static String pcal1="(//*[@id='datePicker1'])";
	    public static String pyear1="(//*[@class='ui-datepicker-year'])";
	    public static String pmonth1="(//*[@class='ui-datepicker-month'])";
	    public static String pdatedone="//*[text()='Done']";
	    public static String pcal2="(//*[@id='datePicker'])";
	    public static String pyear2="(//*[@class='ui-datepicker-year'])";
	    public static String pmonth2="(//*[@class='ui-datepicker-month'])";
	    public static String pdate2="(//*[@class='ui-state-default'])[10]";
	    public static String pterms="(//*[@class='right'])[10]";
	    public static String pbuy="(//*[@class='submit'])";
	    
	    //-------------------------ClaimPolicyContentVerification-------------------------
	  //-------ClaimPolicyContent-------   
	      public static String policyKey="//*[@class='hovertable']/tbody/tr/td[1]";
	      public static String policyEffectiveDate="//*[@class='hovertable']/tbody/tr/td[2]";
	      public static String policyEndDate="//*[@class='hovertable']/tbody/tr/td[3]";
	      public static String policyTerm="//*[@class='hovertable']/tbody/tr/td[4]";
	      public static String policyStatus="//*[@class='hovertable']/tbody/tr/td[5]";
	      
	  //-------ClaimPolicySubmit
	      public static String claimpolicysubmit1="(//*[@class='submit'])[1]";
	      public static String claimpolicysubmit2="(//*[@class='submit'])[2]";
	     
	  //-------ClaimPolicyContent-------       
	      public static String policyKey1="//*[@class='hovertable']/tbody/tr[3]/td[1]";
	      public static String policyEffectiveDate1="//*[@class='hovertable']/tbody/tr[3]/td[2]";
	      public static String policyEndDate1="//*[@class='hovertable']/tbody/tr[3]/td[3]";
	      public static String policyTerm1="//*[@class='hovertable']/tbody/tr[3]/td[4]";
	      public static String policyStatus1="//*[@class='hovertable']/tbody/tr[3]/td[5]";


	    //------------------------ClaimPolicyForm-------------------------------------
	    public static String ClaimPolicyUid = "//*[@id='user']/table/tbody/tr[2]/td[2]/input";
	    public static String ClaimPolicyPwd = "//*[@id='user']/table/tbody/tr[3]/td[2]/input";
	    public static String ClaimPolicyLoginButton = "//*[@id='user']/table/tbody/tr[4]/td[2]/input[1]";
	    public static String ClaimPolicyCPolicy = "//*[@id='navigation']/ul/li[5]/a";
	    public static String ClaimPolicyCPolicyButton = "//*[@id='left']/form/div/table/tbody/tr[2]/td[6]";
	    public static String ClaimPolicyCheckBox1 = "//*[@id='left']/table/tbody/tr[3]/td[2]/input";
	    public static String ClaimPolicyCheckBox2 = "//*[@id='left']/table/tbody/tr[4]/td[2]/input";
	    public static String ClaimPolicyCheckBox3 = "//*[@id='left']/table/tbody/tr[5]/td[2]/input";
	    public static String ClaimPolicyCheckBox4 = "//*[@id='left']/table/tbody/tr[6]/td[2]/input";
	    public static String ClaimPolicyCheckBox5 = "//*[@id='left']/table/tbody/tr[7]/td[2]/input";
	    public static String ClaimPolicyCheckBox6 = "//*[@id='left']/table/tbody/tr[8]/td[2]/input";
	    public static String ClaimPolicyMessage = "//*[@id='left']/table/tbody/tr[9]/td[2]/textarea";
	    public static String ClaimPolicySubmitButton = "//*[@id='left']/table/tbody/tr[10]/td[2]/input";


	
	
	
	
  	

}
